PUERTAS_CHOICES=(
            ('2', '2 Puertas'),
            ('3', '3 Puertas'),
            ('4', '4 Puertas'),
            ('5', '5 Puertas'),
        )

    
GARANTIA_CHOICES = (
        ('0', '2 Meses'),('1', '4 Meses'),
        ('2', '6 Meses'),('3', '8 Meses'),
        ('4', '10 Meses'),('5', '12 Meses'),
        ('6', '14 Meses'),('7', '16 Meses'),
        ('8', '18 Meses'),('9', '20 Meses'),
        ('10', '22 Meses'),('11', '24 Meses'),
        ('12', '28 Meses'),('13', '30 Meses'),
    )
CAMBIO_CHOICES=(
            ('0', 'Automático'),
            ('1', 'Manual'),
            
        )

PROVINCE_CHOICES = (('01', 'Alaba'), ('02', 'Albacete'), ('03', 'Alicante'), ('04', 'Almería'), ('05', 'Ávila'), ('06', 'Badajoz'), ('07', 'Islas Baleares'), ('08', 'Barcelona'), ('09', 'Burgos'), ('10', 'Cáceres'), ('11', 'Cádiz'), ('12', 'Castellón'), ('13', 'Ciudad Real'), ('14', 'Córdoba'), ('15', 'A Coruña'), ('16', 'Cuenca'), ('17', 'Girona'), ('18', 'Granada'), ('19', 'Guadalajara'), ('20', 'Guipúzcoa'), ('21', 'Huelva'), ('22', 'Huesca'), ('23', 'Jaén'), ('24', 'León'), ('25', 'Lleida'), ('26', 'La Rioja'), ('27', 'Lugo'), ('28', 'Madrid'), ('29', 'Málaga'), ('30', 'Murcia'), ('31', 'Navarra'), ('32', 'Ourense'), ('33', 'Asturias'), ('34', 'Palencia'), ('35', 'Las Palmas'), ('36', 'Pontevedra'), ('37', 'Salamanca'), ('38', 'Santa Cruz de Tenerife'), ('39', 'Cantabria'), ('40', 'Segovia'), ('41', 'Sevilla'), ('42', 'Soria'), ('43', 'Tarragona'), ('44', 'Teruel'), ('45', 'Toledo'), ('46', 'Valencia'), ('47', 'Valladolid'), ('48', 'Vizcaya'), ('49', 'Zamora'), ('50', 'Zaragoza'), ('51', 'Ceuta'), ('52', 'Melilla'))
